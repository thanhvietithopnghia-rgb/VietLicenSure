# Hỗ trợ VietLicenSure

Tài liệu này áp dụng cho bản phát hành hiện hành **VietLicenSure v5.0**, phát hành lần đầu ngày `08/09/2026` và cập nhật đến `05/10/2026`.

## Chọn đúng kênh

- **Báo lỗi có thể công khai:** dùng [GitHub Issues](https://github.com/thanhvietithopnghia-rgb/VietLicenSure/issues/new/choose).
- **Hỏi đáp, ý tưởng và đề xuất:** dùng [GitHub Discussions](https://github.com/thanhvietithopnghia-rgb/VietLicenSure/discussions).
- **Lỗ hổng chưa được khắc phục:** dùng [Private vulnerability reporting](https://github.com/thanhvietithopnghia-rgb/VietLicenSure/security/advisories/new), không đăng công khai.
- **Yêu cầu truy cập mã nguồn có kiểm soát:** gửi văn bản tới `thanhvietit.hopnghia@gmail.com` theo [chính sách mã nguồn](SOURCE-POLICY-v5.0.md).
- **Liên hệ trực tiếp:** Zalo `0978 005 017` hoặc email `thanhvietit.hopnghia@gmail.com`.

## Thông tin nên gửi khi báo lỗi

1. Phiên bản hiển thị, ví dụ `VietLicenSure v5.0`.
2. Phiên bản Windows, kiến trúc máy và quyền chạy lúc xảy ra lỗi.
3. Tên chức năng, bước tái hiện ngắn nhất, kết quả mong đợi và kết quả thực tế.
4. Nguyên văn mã lỗi/thông báo và ảnh chụp đã che dữ liệu riêng tư.
5. Gói hỗ trợ đã che định danh do VietLicenSure tạo, nếu cần.

Không gửi product key đầy đủ, mật khẩu, token, mã ghép nối, bí mật Enterprise,
tên máy/IP thật hoặc báo cáo `FullInternal` lên Issues/Discussions.

## Phạm vi hỗ trợ

Dự án ưu tiên lỗi tái hiện được trên bản phát hành chính thức, vấn đề toàn vẹn,
sai kết quả kỹ thuật, lỗi giao diện và đề xuất cải thiện an toàn. VietLicenSure
cung cấp bằng chứng kỹ thuật; hỗ trợ không thay thế tư vấn pháp lý, hồ sơ bản
quyền của nhà cung cấp hoặc quyền quản trị hệ thống của tổ chức.

Mục tiêu phản hồi ban đầu cho báo cáo bảo mật là 5 ngày làm việc; đây là mục tiêu
vận hành, không phải cam kết pháp lý. Thời gian xử lý Issues/Discussions phụ thuộc
mức độ nghiêm trọng, khả năng tái hiện và nguồn lực duy trì dự án.
